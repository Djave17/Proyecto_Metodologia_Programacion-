﻿using System;
using System.IO;

// Definición del struct Actividad
struct Actividad
{
    public string Nombre;
    public string Estado; // Pendiente, En progreso, Finalizado

    public Actividad(string nombre, string estado)
    {
        Nombre = nombre;
        Estado = estado;
    }
}

// Definición del struct FaseCicloVida
struct FaseCicloVida
{
    public string NombreFase;
    public Actividad[] Actividades;

    public FaseCicloVida(string nombreFase, Actividad[] actividades)
    {
        NombreFase = nombreFase;
        Actividades = actividades;
    }
}

class Program
{
    static string nombreDelArchivo = "FasesCicloVida.dat";
    static FaseCicloVida[] fasesCicloVida = CargarFasesCicloVida();

    static void Main()
    {
        int opcion = 0;
        while (opcion != 8)
        {
            opcion = MenuPrincipal();
        }
    }

    static int MenuPrincipal()
    {
        Console.WriteLine("\n------ Menú Principal ------");
        Console.WriteLine("1. Análisis de Requisitos");
        Console.WriteLine("2. Diseño del Sistema");
        Console.WriteLine("3. Implementación");
        Console.WriteLine("4. Pruebas");
        Console.WriteLine("5. Despliegue");
        Console.WriteLine("6. Mantenimiento");
        Console.WriteLine("7. Ver Resumen");
        Console.WriteLine("8. Salir");
        int opcion = ObtenerEnteroValido("Seleccione una opción: ");

        switch (opcion)
        {
            case 1: MenuFase(0); break;
            case 2: MenuFase(1); break;
            case 3: MenuFase(2); break;
            case 4: MenuFase(3); break;
            case 5: MenuFase(4); break;
            case 6: MenuFase(5); break;
            case 7: VerResumen(); break;
            case 8: Console.WriteLine("Saliendo..."); GuardarFasesCicloVida(fasesCicloVida); break;
            default: Console.WriteLine("Opción no válida."); break;
        }
        return opcion;
    }

    static void MenuFase(int indexFase)
    {
        int opcion = 0;
        while (opcion != 4)
        {
            Console.WriteLine($"\n--- Menú de {fasesCicloVida[indexFase].NombreFase} ---");
            Console.WriteLine("1. Agregar actividad");
            Console.WriteLine("2. Actualizar actividad");
            Console.WriteLine("3. Eliminar actividad");
            Console.WriteLine("4. Volver al menú principal");

            opcion = ObtenerEnteroValido("Seleccione una opción: ");

            switch (opcion)
            {
                case 1: AgregarActividad(indexFase); break;
                case 2: ActualizarActividad(indexFase); break;
                case 3: EliminarActividad(indexFase); break;
                case 4: Console.Clear(); break;
                default: Console.WriteLine("Opción no válida."); break;
            }
        }
    }

    static void AgregarActividad(int indexFase)
    {
        string nombre = ObtenerEntradaValida("Ingrese el nombre de la actividad: ");
        string estado = ObtenerEstadoValido("Ingrese el estado (Pendiente, En progreso, Finalizado): ");

        Actividad[] nuevasActividades = new Actividad[fasesCicloVida[indexFase].Actividades.Length + 1];

        // Crea un nuevo array con una actividad más que el original
        Array.Copy(fasesCicloVida[indexFase].Actividades, nuevasActividades, fasesCicloVida[indexFase].Actividades.Length);

        nuevasActividades[nuevasActividades.Length - 1] = new Actividad(nombre, estado);

        fasesCicloVida[indexFase].Actividades = nuevasActividades;
        GuardarFasesCicloVida(fasesCicloVida);
    }

    static void ActualizarActividad(int indexFase)
    {
        VerActividades(fasesCicloVida[indexFase]);
        int numActividad = ObtenerEnteroValido("Seleccione el número de la actividad a actualizar: ") - 1;

        if (numActividad >= 0 && numActividad < fasesCicloVida[indexFase].Actividades.Length)
        {
            string nuevoEstado = ObtenerEstadoValido("Ingrese el nuevo estado (Pendiente, En progreso, Finalizado): ");
            fasesCicloVida[indexFase].Actividades[numActividad].Estado = nuevoEstado;
            GuardarFasesCicloVida(fasesCicloVida);
        }
        else
        {
            Console.WriteLine("Número de actividad no válido.");
        }
    }

    static void EliminarActividad(int indexFase)
    {
        VerActividades(fasesCicloVida[indexFase]);
        int numActividad = ObtenerEnteroValido("Seleccione el número de la actividad a eliminar: ") - 1;

        if (numActividad >= 0 && numActividad < fasesCicloVida[indexFase].Actividades.Length)
        {
            Actividad[] nuevasActividades = new Actividad[fasesCicloVida[indexFase].Actividades.Length - 1];

            for (int i = 0, j = 0; i < fasesCicloVida[indexFase].Actividades.Length; i++)
            {
                if (i != numActividad)
                {
                    nuevasActividades[j++] = fasesCicloVida[indexFase].Actividades[i];
                }
            }

            fasesCicloVida[indexFase].Actividades = nuevasActividades;
            GuardarFasesCicloVida(fasesCicloVida);
        }
        else
        {
            Console.WriteLine("Número de actividad no válido.");
        }
    }

    static void VerResumen()
    {
        Console.WriteLine("\n--- Resumen del ciclo de vida ---");
        foreach (var fase in fasesCicloVida)
        {
            Console.WriteLine($"\nFase: {fase.NombreFase}");
            VerActividades(fase);
        }
    }

    static void VerActividades(FaseCicloVida fase)
    {
        if (fase.Actividades.Length == 0)
        {
            Console.WriteLine("No hay actividades registradas.");
            return;
        }

        for (int i = 0; i < fase.Actividades.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {fase.Actividades[i].Nombre} - {fase.Actividades[i].Estado}");
        }
    }

    // Método para cargar las fases del archivo binario
    static FaseCicloVida[] CargarFasesCicloVida()
    {
        if (!File.Exists(nombreDelArchivo))
        {
            // Si no existe el archivo, inicializa con las fases predeterminadas
            return new FaseCicloVida[]
            {
                new FaseCicloVida("Análisis de Requisitos", new Actividad[0]),
                new FaseCicloVida("Diseño del Sistema", new Actividad[0]),
                new FaseCicloVida("Implementación", new Actividad[0]),
                new FaseCicloVida("Pruebas", new Actividad[0]),
                new FaseCicloVida("Despliegue", new Actividad[0]),
                new FaseCicloVida("Mantenimiento", new Actividad[0])
            };
        }

        using (FileStream fs = new FileStream(nombreDelArchivo, FileMode.Open))
        using (BinaryReader reader = new BinaryReader(fs))
        {
            int numFases = reader.ReadInt32();
            FaseCicloVida[] fases = new FaseCicloVida[numFases];

            for (int i = 0; i < numFases; i++)
            {
                string nombreFase = reader.ReadString();
                int numActividades = reader.ReadInt32();
                Actividad[] actividades = new Actividad[numActividades];

                for (int j = 0; j < numActividades; j++)
                {
                    string nombreActividad = reader.ReadString();
                    string estadoActividad = reader.ReadString();
                    actividades[j] = new Actividad(nombreActividad, estadoActividad);
                }

                fases[i] = new FaseCicloVida(nombreFase, actividades);
            }

            return fases;
        }
    }

    // Método para guardar las fases en un archivo binario
    static void GuardarFasesCicloVida(FaseCicloVida[] fases)
    {
        using (FileStream fs = new FileStream(nombreDelArchivo, FileMode.Create))
        using (BinaryWriter writer = new BinaryWriter(fs))
        {
            writer.Write(fases.Length);

            foreach (var fase in fases)
            {
                writer.Write(fase.NombreFase);
                writer.Write(fase.Actividades.Length);

                foreach (var actividad in fase.Actividades)
                {
                    writer.Write(actividad.Nombre);
                    writer.Write(actividad.Estado);
                }
            }
        }
    }

    // Método para validar la entrada no vacía
    static string ObtenerEntradaValida(string mensaje)
    {
        string entrada;
        do
        {
            Console.Write(mensaje);
            entrada = Console.ReadLine();
        } while (string.IsNullOrEmpty(entrada));

        return entrada;
    }

    // Método para validar que la entrada sea un entero
    static int ObtenerEnteroValido(string mensaje)
    {
        int valor;
        while (!int.TryParse(ObtenerEntradaValida(mensaje), out valor))
        {
            Console.WriteLine("Debe ingresar un número válido.");
        }

        return valor;
    }

    // Método para validar el estado de la actividad
    static string ObtenerEstadoValido(string mensaje)
    {
        string estado;
        do
        {
            estado = ObtenerEntradaValida(mensaje);
        } while (estado != "Pendiente" && estado != "En progreso" && estado != "Finalizado");

        return estado;
    }
}