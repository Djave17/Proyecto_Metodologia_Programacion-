﻿using System;
using System.IO;

struct RegistroSoftware
{
    public string Fabricante;
    public string Nombre;
    public string Version;
    public string Edicion;
    public string Licenciamiento;
    public string Descripcion;

    public RegistroSoftware(string fabricante, string nombre, string version,
        string edicion, string licenciamiento, string descripcion)
    {
        Fabricante = fabricante;
        Nombre = nombre;
        Version = version;
        Edicion = edicion;
        Licenciamiento = licenciamiento;
        Descripcion = descripcion;
    }
}

public class Program
{
    static string nombreDelArchivo = "Archivo.dat";

    static void Main()
    {
        RegistroSoftware[] registroSoftware = CargarRegistros(); // Cargar registros del archivo

        int x = Menu(registroSoftware); 
    }

    static RegistroSoftware[] CrearNuevosRegistros(RegistroSoftware[] registroSoftware)
    {
        Console.Write("Ingrese cantidad a registrar: ");
        int cantidadDeRegistros = int.Parse(Console.ReadLine());

        RegistroSoftware[] nuevosRegistros = new RegistroSoftware[registroSoftware.Length + cantidadDeRegistros];

        // Copiar registros anteriores
        Array.Copy(registroSoftware, nuevosRegistros, registroSoftware.Length);

        // Añadir nuevos registros
        for (int i = registroSoftware.Length; i < nuevosRegistros.Length; i++)
        {
            string fabricante = " ";
            string nombre = " ";
            string edicion = " ";
            string version = " ";
            string licenciamiento = " ";
            string descripcion = " ";

            bool isOk = true;
            //Fabricante
            while (isOk == true)
            {

                Console.Write($"Fabricante #{i + 1}: ");
                fabricante = Console.ReadLine();
                if (fabricante == null || fabricante.Trim() == "")
                {
                    Console.WriteLine("EL fabricante no puede estar vacío...");
                }
                else
                    isOk = false;
                

            }
            //Nombre 
            isOk = true;
            while (isOk == true)
            {
              

                Console.Write($"Nombre #{i + 1}: ");
                nombre = Console.ReadLine();
                if (nombre == null || nombre.Trim() == "")
                {
                    Console.WriteLine("EL nombre no puede estar vacío...");
                }
                else
                    isOk = false;




            }
            //Edicion
            isOk = true;
            while (isOk == true)
            {
                Console.Write($"Edicion #{i + 1}: ");
                edicion = Console.ReadLine();
                if (edicion == null || edicion.Trim() == "")
                {
                    Console.WriteLine("La edicion no puede estar vacía...");
                }
                else
                    isOk = false;

            }

            //Version
            isOk = true;
            while (isOk == true)
            {
                Console.Write($"Version #{i + 1}: ");
                version = Console.ReadLine();
                if (version == null || version.Trim() == "")
                {
                    Console.WriteLine("La version no puede estar vacía...");
                }
                else
                    isOk = false;
            }

            //Licenciamiento
            isOk = true;
            while (isOk == true)
            {
                Console.Write($"Licenciamiento #{i + 1}: ");
                licenciamiento = Console.ReadLine();
                if (version == null || version.Trim() == "")
                {
                    Console.WriteLine("El licenciamiento no puede estar vacío...");
                }
                else
                    isOk = false;
                
            }

            // Descripcion
            isOk = true;
            while (isOk == true)
            {
                Console.Write($"Descripcion #{i + 1}: ");
                descripcion = Console.ReadLine();
                if (version == null || version.Trim() == "")
                {
                    Console.WriteLine("La descripcion no puede estar vacía...");
                }
                else
                    isOk = false;
            }

            nuevosRegistros[i] = new RegistroSoftware(fabricante, nombre, version, edicion, licenciamiento, descripcion);
        }

        return nuevosRegistros;
    }

    static void GuardarRegistros(RegistroSoftware[] registroSoftware)
    {
        using (FileStream fs = new FileStream(nombreDelArchivo, FileMode.Create))
        using (BinaryWriter writer = new BinaryWriter(fs))
        {
            writer.Write(registroSoftware.Length); // Guardar la cantidad de registros
            foreach (var registro in registroSoftware)
            {
                writer.Write(registro.Fabricante);
                writer.Write(registro.Nombre);
                writer.Write(registro.Edicion);
                writer.Write(registro.Version);
                writer.Write(registro.Licenciamiento);
                writer.Write(registro.Descripcion);
            }
        }
    }

    static RegistroSoftware[] CargarRegistros()
    {
        if (!File.Exists(nombreDelArchivo))
        {
            return new RegistroSoftware[0]; // Retornar un arreglo vacío si el archivo no existe
        }

        using (FileStream fs = new FileStream(nombreDelArchivo, FileMode.Open))
        using (BinaryReader reader = new BinaryReader(fs))
        {
            int cantidadDeRegistros = reader.ReadInt32(); // Leer la cantidad de registros
            RegistroSoftware[] registroSoftware = new RegistroSoftware[cantidadDeRegistros];

            for (int i = 0; i < cantidadDeRegistros; i++)
            {
                string fabricante = reader.ReadString();
                string nombre = reader.ReadString();
                string edicion = reader.ReadString();
                string version = reader.ReadString();
                string licenciamiento = reader.ReadString();
                string descripcion = reader.ReadString();

                registroSoftware[i] = new RegistroSoftware(fabricante, nombre, version, edicion, licenciamiento, descripcion);
            }

            return registroSoftware;
        }
    }

    static void MostrarRegistros(RegistroSoftware[] registroSoftware)
    {
        if (registroSoftware.Length == 0)
        {
            Console.WriteLine("No hay registros para mostrar.");
            return;
        }

        int labelWidth = 15;
        int indiceWidth = 5; // Ancho para el índice

        // Imprimir encabezados
        Console.WriteLine(
            $"{"Número".PadRight(indiceWidth)} {"Fabricante".PadRight(labelWidth)} {"Nombre".PadRight(labelWidth)} {"Edición".PadRight(labelWidth)} " +
            $"{"Versión".PadRight(labelWidth)} {"Licenciamiento".PadRight(labelWidth)} {"Descripción".PadRight(labelWidth)}"
        );

        // Imprimir una línea de separación
        Console.WriteLine(new string('-', indiceWidth + (labelWidth * 6)));

        // Imprimir los registros con formato alineado
        for (int i = 0; i < registroSoftware.Length; i++)
        {
            Console.WriteLine(
                $"{i.ToString().PadRight(indiceWidth)} {registroSoftware[i].Fabricante.PadRight(labelWidth)} {registroSoftware[i].Nombre.PadRight(labelWidth)} {registroSoftware[i].Edicion.PadRight(labelWidth)} " +
                $"{registroSoftware[i].Version.PadRight(labelWidth)} {registroSoftware[i].Licenciamiento.PadRight(labelWidth)} {registroSoftware[i].Descripcion.PadRight(labelWidth)}"
            );
        }
    }

    static RegistroSoftware[] EliminarRegistro(RegistroSoftware[] registroSoftware)
    {


        // Buscar el índice del registro a eliminar
        Console.Write("Ingrese el índice del software a eliminar: ");
        int index = int.Parse(Console.ReadLine());

        MostrarBuscar(registroSoftware, index);

        //Preguntar al usuario
        Console.WriteLine("\n¿Desea eliminar este registro? (Si = 1/ No = 0)");
        int op = int.Parse(Console.ReadLine());
        if(op == 0)
        {
            Console.WriteLine("\nVolviendo a menu...");
            Menu(registroSoftware);
       
        }
        else if(op == 1)
        {
            Console.WriteLine("\nPulse cualquier tecla para borrar...");

        }
        else
        {
            Console.WriteLine("Opcion invalida...\nVolviendo a menu...");
            Menu(registroSoftware);

        }

        // Crear un nuevo arreglo excluyendo el registro eliminado
        RegistroSoftware[] nuevosRegistros = new RegistroSoftware[registroSoftware.Length - 1];
        for (int i = 0, j = 0; i < registroSoftware.Length; i++)
        {
            if (i != index)
            {
                nuevosRegistros[j] = registroSoftware[i];
                j++;
            }
        }

        Console.WriteLine("Registro eliminado exitosamente.");
        return nuevosRegistros;
    }

    static RegistroSoftware[] ActualizarRegistro(RegistroSoftware[] registroSoftware)
    {
        Console.Write("Ingrese el índice del software a actualizar: ");
        int index = int.Parse(Console.ReadLine());

        MostrarBuscar(registroSoftware, index);
   
   
        //Preguntar al usuario
        Console.WriteLine("\n¿Desea eliminar este actualizar? (Si = 1/ No = 0)");
        int op = int.Parse(Console.ReadLine());
        if (op == 0)
        {
            Console.WriteLine("\nVolviendo a menu...");
            Menu(registroSoftware);

        }
        else if (op == 1)
        {
            Console.WriteLine("\nPulse cualquier tecla para actualizar...");

        }
        else
        {
            Console.WriteLine("Opcion invalida...\nVolviendo a menu...");
            Menu(registroSoftware);

        }

        // Actualizar los campos del registro
        Console.WriteLine("Ingrese los nuevos valores (deje en blanco para no cambiar):");

        Console.Write("Nuevo fabricante: ");
        string nuevoFabricante = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevoFabricante)) registroSoftware[index].Fabricante = nuevoFabricante;

        Console.Write("Nuevo nombre: ");
        string nuevoNombre = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevoNombre)) registroSoftware[index].Nombre = nuevoNombre;

        Console.Write("Nueva edición: ");
        string nuevaEdicion = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevaEdicion)) registroSoftware[index].Edicion = nuevaEdicion;

        Console.Write("Nueva versión: ");
        string nuevaVersion = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevaVersion)) registroSoftware[index].Version = nuevaVersion;

        Console.Write("Nuevo licenciamiento: ");
        string nuevoLicenciamiento = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevoLicenciamiento)) registroSoftware[index].Licenciamiento = nuevoLicenciamiento;

        Console.Write("Nueva descripción: ");
        string nuevaDescripcion = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevaDescripcion)) registroSoftware[index].Descripcion = nuevaDescripcion;

        Console.WriteLine("Registro actualizado exitosamente.");
        return registroSoftware;
    }

    static void LimpiarPantalla()
    {
        Console.ReadKey();
        Console.Clear();
    }

    static int BuscarIndicePorNombre(RegistroSoftware[] registroSoftware, int indice) //Encontrar el numero indice mostrado 
    {
        

        int cantidadDeIndices = registroSoftware.Length;

        // Comprobar si el índice está fuera de los límites del arreglo
        if (indice < 0 || indice >= cantidadDeIndices) // Cambiado `>` a `>=` para incluir el último índice
        {
            Console.WriteLine("El índice no existe...");
            return -1; // Retornar -1 para indicar que el índice es inválido
        }

        // Si el índice es válido, se notifica al usuario y se devuelve el índice
        Console.WriteLine("Registro de software encontrado...");
        return indice;





    }

    static int Menu(RegistroSoftware[] registroSoftware)
    {
        int op = 0; 
        while (op != 5)
        {
            //LimpiarPantalla(); 
            Console.WriteLine("-----------Menu----------");
            Console.WriteLine("1. Crear nuevo registro");
            Console.WriteLine("2. Leer/Mostrar registros");
            Console.WriteLine("3. Eliminar registro");
            Console.WriteLine("4. Actualizar registro");
            Console.WriteLine("5. Salir");
            Console.Write("- Opción: ");
            op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1:
                    registroSoftware = CrearNuevosRegistros(registroSoftware);
                    GuardarRegistros(registroSoftware); // Guardar en el archivo
                    LimpiarPantalla();
                    break;

                case 2:
                    MostrarRegistros(registroSoftware);
                    LimpiarPantalla();
                    break;

                case 3:
                    registroSoftware = EliminarRegistro(registroSoftware);
                    GuardarRegistros(registroSoftware); // Guardar en el archivo
                    LimpiarPantalla();

                    break;

                case 4:
                    registroSoftware = ActualizarRegistro(registroSoftware);
                    GuardarRegistros(registroSoftware); // Guardar en el archivo
                    LimpiarPantalla();

                    break;

                case 5:
                    break;

                default:
                    Console.WriteLine("Opción invalida... intente nuevamente");
                    break;
            }

        }
        return 0;
    }

    static void MostrarBuscar(RegistroSoftware[] registroSoftware, int indice)
    {
        int labelWidth = 15;
        int indiceWidth = 5; // Ancho para el índice

        // Imprimir encabezados
        Console.WriteLine(
            $"{"Número".PadRight(indiceWidth)} {"Fabricante".PadRight(labelWidth)} {"Nombre".PadRight(labelWidth)} {"Edición".PadRight(labelWidth)} " +
            $"{"Versión".PadRight(labelWidth)} {"Licenciamiento".PadRight(labelWidth)} {"Descripción".PadRight(labelWidth)}"
        );

        // Imprimir una línea de separación
        Console.WriteLine(new string('-', indiceWidth + (labelWidth * 6)));

        // Imprimir los registros con formato alineado
        int i = BuscarIndicePorNombre(registroSoftware, indice);
        if(i == -1)
        {
            Menu(registroSoftware); 
        }

        Console.WriteLine(
                $"{i.ToString().PadRight(indiceWidth)} {registroSoftware[i].Fabricante.PadRight(labelWidth)} {registroSoftware[i].Nombre.PadRight(labelWidth)} {registroSoftware[i].Edicion.PadRight(labelWidth)} " +
                $"{registroSoftware[i].Version.PadRight(labelWidth)} {registroSoftware[i].Licenciamiento.PadRight(labelWidth)} {registroSoftware[i].Descripcion.PadRight(labelWidth)}"
            );
    }

}
