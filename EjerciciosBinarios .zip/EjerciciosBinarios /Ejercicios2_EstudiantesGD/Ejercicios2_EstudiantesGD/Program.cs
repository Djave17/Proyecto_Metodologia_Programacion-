﻿using System;
using System.IO;

// Definición del struct Asignatura
struct Asignatura
{
    public string NombreAsignatura;
    public double Calificacion;

    public Asignatura(string nombreAsignatura, double calificacion)
    {
        NombreAsignatura = nombreAsignatura;
        Calificacion = calificacion;
    }
}

// Definición del struct Estudiante
struct Estudiante
{
    public int ID;
    public string Nombre;
    public int Año;
    public int Semestre;
    public Asignatura[] Asignaturas;

    public Estudiante(int id, string nombre, int año, int semestre, Asignatura[] asignaturas)
    {
        ID = id;
        Nombre = nombre;
        Año = año;
        Semestre = semestre;
        Asignaturas = asignaturas;
    }
}

class Program
{
    static string nombreDelArchivo = "Estudiantes.dat";
    // Carga estudiantes mediante un static de estructura 
    static Estudiante[] estudiantes = CargarEstudiantes();


    static int siguienteID = estudiantes.Length; //Variable de control de ID estudiantes

    public static void Main()
    {
        int opcion = 0;
        while (opcion != 6)
        {
            opcion = MenuPrincipal();
        }
    }

    static int MenuPrincipal()
    {
        
        Console.WriteLine("------ Menú Principal ------");
        Console.WriteLine("1. Agregar Estudiante");
        Console.WriteLine("2. Ver Estudiantes");
        Console.WriteLine("3. Buscar Estudiante");
        Console.WriteLine("4. Actualizar Estudiante");
        Console.WriteLine("5. Eliminar Estudiante");
        Console.WriteLine("6. Salir");
        int opcion = ObtenerEnteroValido("Digite una opcion: ");

        switch (opcion)
        {
            case 1: //Agregar
                estudiantes = AgregarEstudiante(estudiantes);
                GuardarEstudiantes(estudiantes);
                Console.Clear();
                break;
            case 2: //Ver todos los estudiantes
                VerEstudiantes(estudiantes);
                Console.ReadKey();
                Console.Clear();
                break;
            case 3: // Ver un estudiante
                BuscarEstudiante(estudiantes);
                Console.ReadKey();
                Console.Clear();
                break;
            case 4://Actualizar estudiante 
                ActualizarEstudiante();
                Console.ReadKey();
                Console.Clear();
                break;
            case 5: //Eliminar estudiante
                EliminarEstudiante(estudiantes);
                Console.ReadKey();
                Console.Clear();
                break;
            case 6:
                Console.WriteLine("Saliendo...");
                
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
        return opcion;
    }

    static Estudiante[] AgregarEstudiante(Estudiante[] estudiantes)
    {
        int cantidad = ObtenerEnteroValido("Ingrese cantidad de estudiantes a agregar: ");

        // Crea un nuevo arreglo con espacio adicional para los nuevos estudiantes
        Estudiante[] nuevosEstudiantes = new Estudiante[estudiantes.Length + cantidad];

        // Copia los estudiantes existentes al nuevo arreglo
        Array.Copy(estudiantes, nuevosEstudiantes, estudiantes.Length);


        for (int i = estudiantes.Length; i < nuevosEstudiantes.Length; i++)
        {
            int id = ++siguienteID;
            string nombre = ObtenerEntradaValida("Nombre del estudiante: ");
            int año = ObtenerEnteroValido("Año: ");
            int semestre = ObtenerEnteroValido("Semestre: ");

            int numAsignaturas = ObtenerEnteroValido("Ingrese cantidad de asignatura a agregar: ");
            Asignatura[] asignaturas = new Asignatura[numAsignaturas];

            // For para numero de asignaturas
            for (int j = 0; j < numAsignaturas; j++)
            {
                string nombreAsignatura = ObtenerEntradaValida("Nombre de la asignatura: ");
                Console.Write("Calificación: ");
                double calificacion = double.Parse(Console.ReadLine());
                asignaturas[j] = new Asignatura(nombreAsignatura, calificacion);
            }

            nuevosEstudiantes[i] = new Estudiante(id, nombre, año, semestre, asignaturas);
        }

        return nuevosEstudiantes;
    }


    static void VerEstudiantes(Estudiante[] estudiantes)
    {
        if (estudiantes.Length == 0)
        {
            Console.WriteLine("No hay estudiantes registrados.");
            return;
        }

        Console.WriteLine("---------- Estudiantes ----------");
        Console.WriteLine("---------------------------------------------------------------------");
        Console.WriteLine("| {0,-5} | {1,-15} | {2,-4} | {3,-8} | {4,-20} |", "ID", "Nombre", "Año", "Semestre", "Asignaturas");
        Console.WriteLine("---------------------------------------------------------------------");

        foreach (var estudiante in estudiantes)
        {
            Console.Write("| {0,-5} | {1,-15} | {2,-4} | {3,-8} |", estudiante.ID, estudiante.Nombre, estudiante.Año, estudiante.Semestre);

            foreach (var asignatura in estudiante.Asignaturas)
            {
                Console.WriteLine(" {0}: {1}", asignatura.NombreAsignatura, asignatura.Calificacion);
            }
            Console.WriteLine("---------------------------------------------------------------------");
        }
    }

    static void BuscarEstudiante(Estudiante[] estudiantes)
    {
      
        int id = ObtenerEnteroValido("Ingrese el ID del estudiante a buscar: ");
        Estudiante? estudianteEncontrado = null;

        foreach (var estudiante in estudiantes)
        {
            if (estudiante.ID == id)
            {
                estudianteEncontrado = estudiante;
                break;
            }
        }

        if (estudianteEncontrado == null)
        {
            Console.WriteLine("Estudiante no encontrado.");
            return;
        }

        var est = estudianteEncontrado.Value;
        Console.WriteLine("-------------------------------------------------------------------");
        Console.WriteLine("| ID  | Nombre           | Año  | Semestre | Asignaturas          |");
        Console.WriteLine("-------------------------------------------------------------------");
        Console.Write("| {0,-3} | {1,-15} | {2,-4} | {3,-8} |", est.ID, est.Nombre, est.Año, est.Semestre);
        foreach (var asignatura in est.Asignaturas)
        {
            Console.WriteLine("  {0}: {1}", asignatura.NombreAsignatura, asignatura.Calificacion);
        }
        Console.WriteLine("-------------------------------------------------------------------");
    }

    static void ActualizarEstudiante()
    {
        
        int id = ObtenerEnteroValido("Ingrese el ID del estudiante a buscar: ");

        for (int i = 0; i < estudiantes.Length; i++)
        {
            if (estudiantes[i].ID == id)
            {
                Console.Write("Nuevo Nombre (dejar en blanco para no cambiar): ");
                string nuevoNombre = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(nuevoNombre))
                {
                    estudiantes[i].Nombre = nuevoNombre;
                }

                Console.Write("Nuevo Año (dejar en blanco para no cambiar): ");
                string nuevoAño = Console.ReadLine();
                if (int.TryParse(nuevoAño, out int año))
                {
                    estudiantes[i].Año = año;
                }

                Console.Write("Nuevo Semestre (dejar en blanco para no cambiar): ");
                string nuevoSemestre = Console.ReadLine();
                if (int.TryParse(nuevoSemestre, out int semestre))
                {
                    estudiantes[i].Semestre = semestre;
                }

                GuardarEstudiantes(estudiantes);
                Console.WriteLine("Estudiante actualizado correctamente.");
                return;
            }
        }

        Console.WriteLine("Estudiante no encontrado.");
    }

    static void EliminarEstudiante(Estudiante[] estudiantes)
    {
        Console.Write("Ingrese el ID del estudiante a eliminar: ");
        int id = int.Parse(Console.ReadLine());
        int index = -1;

        for (int i = 0; i < estudiantes.Length; i++)
        {
            if (estudiantes[i].ID == id)
            {
                index = i;
                break;
            }
        }

        if (index == -1)
        {
            Console.WriteLine("Estudiante no encontrado.");
            return;
        }

        // Crea un nuevo arreglo sin el estudiante eliminado
        Estudiante[] nuevosEstudiantes = new Estudiante[estudiantes.Length - 1];
        for (int i = 0, j = 0; i < estudiantes.Length; i++)
        {
            if (i != index)
            {
                nuevosEstudiantes[j++] = estudiantes[i];
            }
        }

        Console.WriteLine("Estudiante eliminado exitosamente...");
        GuardarEstudiantes(nuevosEstudiantes);
        estudiantes = nuevosEstudiantes;
 
        // Continuar el flujo del menú sin cerrar el programa


    }

    static void GuardarEstudiantes(Estudiante[] estudiantes)
    {
        using (FileStream fs = new FileStream(nombreDelArchivo, FileMode.Create))
        using (BinaryWriter writer = new BinaryWriter(fs))
        {
            writer.Write(estudiantes.Length);
            foreach (var estudiante in estudiantes)
            {
                writer.Write(estudiante.ID);
                writer.Write(estudiante.Nombre);
                writer.Write(estudiante.Año);
                writer.Write(estudiante.Semestre);
                writer.Write(estudiante.Asignaturas.Length);

                foreach (var asignatura in estudiante.Asignaturas)
                {
                    writer.Write(asignatura.NombreAsignatura);
                    writer.Write(asignatura.Calificacion);
                }
            }
        }
    }

    static Estudiante[] CargarEstudiantes()
    {
        if (!File.Exists(nombreDelArchivo))
        {
            return new Estudiante[0];
        }

        using (FileStream fs = new FileStream(nombreDelArchivo, FileMode.Open))
        using (BinaryReader reader = new BinaryReader(fs))
        {
            // Lee la cantidad total de estudiantes almacenados
            int cantidadEstudiantes = reader.ReadInt32();
            //Declara el struct en base al total de estudiantes almacenados 
            Estudiante[] estudiantes = new Estudiante[cantidadEstudiantes];

            // Itera para leer cada estudiante
            for (int i = 0; i < cantidadEstudiantes; i++)
            {
                int id = reader.ReadInt32();
                string nombre = reader.ReadString();
                int año = reader.ReadInt32();
                int semestre = reader.ReadInt32();
                int numAsignaturas = reader.ReadInt32();

                Asignatura[] asignaturas = new Asignatura[numAsignaturas];
                for (int j = 0; j < numAsignaturas; j++)
                {
                    string nombreAsignatura = reader.ReadString();
                    double calificacion = reader.ReadDouble();
                    asignaturas[j] = new Asignatura(nombreAsignatura, calificacion);
                }
                // Crea un nuevo estudiante con los datos leídos
                estudiantes[i] = new Estudiante(id, nombre, año, semestre, asignaturas);
            }

            return estudiantes;
        }

    }
    // Método para validar entradas no vacías
    static string ObtenerEntradaValida(string mensaje)
    {
        string entrada;
        do
        {
            Console.Write(mensaje);
            entrada = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(entrada))
            {
                Console.WriteLine("Este campo no puede estar vacío, por favor intente de nuevo\n.");
            }
        } while (string.IsNullOrWhiteSpace(entrada));

        return entrada;
    }

    // Método para validar entradas de tipo int
    static int ObtenerEnteroValido(string mensaje)
    {
        int valor;
        bool esValido = false;
        do
        {
            Console.Write(mensaje);
            string entrada = Console.ReadLine();
            esValido = int.TryParse(entrada, out valor);
            if (!esValido)
            {
                Console.WriteLine("Entrada no válida. Por favor, ingrese un número entero.");
            }
        } while (!esValido);

        return valor;
    }
}
